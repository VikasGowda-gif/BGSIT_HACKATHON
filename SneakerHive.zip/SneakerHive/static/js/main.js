// Main Application JavaScript
class FootcapApp {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.cart = JSON.parse(localStorage.getItem('footcap_cart')) || [];
        this.wishlist = JSON.parse(localStorage.getItem('footcap_wishlist')) || [];
        this.currentFilter = 'all';
        
        this.init();
    }
    
    async init() {
        await this.loadProducts();
        this.setupEventListeners();
        this.setupNavigation();
        this.setupModals();
        this.setupScrollEffects();
        this.updateCartCounter();
        this.updateWishlistCounter();
        this.hideLoadingScreen();
        this.renderProducts();
    }
    
    // Product Management
    async loadProducts() {
        try {
            const response = await fetch('/api/products');
            this.products = await response.json();
            this.filteredProducts = [...this.products];
        } catch (error) {
            console.error('Error loading products:', error);
            this.showNotification('Error loading products', 'error');
        }
    }
    
    renderProducts() {
        const productsGrid = document.getElementById('productsGrid');
        if (!productsGrid) return;
        
        // Clear existing products
        productsGrid.innerHTML = '';
        
        if (this.filteredProducts.length === 0) {
            productsGrid.innerHTML = `
                <div class="no-products">
                    <i class="fas fa-search" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
                    <p>No products found matching your criteria.</p>
                </div>
            `;
            return;
        }
        
        this.filteredProducts.forEach((product, index) => {
            const productCard = this.createProductCard(product, index);
            productsGrid.appendChild(productCard);
        });
    }
    
    createProductCard(product, index) {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        const isInWishlist = this.wishlist.some(item => item.id === product.id);
        const heartClass = isInWishlist ? 'fas fa-heart' : 'far fa-heart';
        
        card.innerHTML = `
            <div class="product-image">
                <i class="fas fa-shoe-prints"></i>
                <div class="product-actions">
                    <button class="action-btn wishlist-toggle" data-id="${product.id}" title="Add to Wishlist">
                        <i class="${heartClass}"></i>
                    </button>
                    <button class="action-btn quick-view" data-id="${product.id}" title="Quick View">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div class="product-info">
                <div class="product-brand">${product.brand}</div>
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-footer">
                    <div class="product-price">$${product.price.toFixed(2)}</div>
                    <button class="add-to-cart" data-id="${product.id}">
                        <i class="fas fa-cart-plus"></i> Add to Cart
                    </button>
                </div>
            </div>
        `;
        
        return card;
    }
    
    // Filtering
    filterProducts(brand) {
        this.currentFilter = brand;
        
        if (brand === 'all') {
            this.filteredProducts = [...this.products];
        } else {
            this.filteredProducts = this.products.filter(product => 
                product.brand.toLowerCase() === brand.toLowerCase()
            );
        }
        
        this.renderProducts();
        this.updateFilterButtons();
    }
    
    filterProductsByCategory(category) {
        this.filteredProducts = this.products.filter(product => 
            product.category.toLowerCase() === category.toLowerCase()
        );
        this.renderProducts();
        this.scrollToSection('#products');
    }
    
    updateFilterButtons() {
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === this.currentFilter) {
                btn.classList.add('active');
            }
        });
    }
    
    // Search Functionality
    searchProducts(query) {
        if (!query.trim()) {
            this.filteredProducts = [...this.products];
        } else {
            this.filteredProducts = this.products.filter(product =>
                product.name.toLowerCase().includes(query.toLowerCase()) ||
                product.brand.toLowerCase().includes(query.toLowerCase()) ||
                product.category.toLowerCase().includes(query.toLowerCase()) ||
                product.description.toLowerCase().includes(query.toLowerCase())
            );
        }
        
        this.renderProducts();
        this.renderSearchResults(query);
    }
    
    renderSearchResults(query) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;
        
        if (!query.trim()) {
            searchResults.innerHTML = '';
            return;
        }
        
        searchResults.innerHTML = `
            <h4>Search Results for "${query}" (${this.filteredProducts.length} found)</h4>
            <div class="search-results-grid">
                ${this.filteredProducts.map(product => `
                    <div class="search-result-item" onclick="app.openQuickView(${product.id})">
                        <div class="search-result-icon">
                            <i class="fas fa-shoe-prints"></i>
                        </div>
                        <div class="search-result-info">
                            <h5>${product.name}</h5>
                            <p>${product.brand} - $${product.price.toFixed(2)}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    getSearchSuggestions(query) {
        if (!query.trim()) return [];
        
        const suggestions = new Set();
        
        this.products.forEach(product => {
            if (product.name.toLowerCase().includes(query.toLowerCase())) {
                suggestions.add(product.name);
            }
            if (product.brand.toLowerCase().includes(query.toLowerCase())) {
                suggestions.add(product.brand);
            }
            if (product.category.toLowerCase().includes(query.toLowerCase())) {
                suggestions.add(product.category);
            }
        });
        
        return Array.from(suggestions).slice(0, 5);
    }
    
    renderSearchSuggestions(suggestions) {
        const suggestionsContainer = document.getElementById('searchSuggestions');
        if (!suggestionsContainer) return;
        
        if (suggestions.length === 0) {
            suggestionsContainer.innerHTML = '';
            return;
        }
        
        suggestionsContainer.innerHTML = `
            <h4>Suggestions</h4>
            ${suggestions.map(suggestion => `
                <div class="search-suggestion" onclick="app.selectSuggestion('${suggestion}')">
                    ${suggestion}
                </div>
            `).join('')}
        `;
    }
    
    selectSuggestion(suggestion) {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.value = suggestion;
            this.searchProducts(suggestion);
        }
    }
    
    // Cart Management
    addToCart(productId) {
        const product = this.products.find(p => p.id === parseInt(productId));
        if (!product) return;
        
        const existingItem = this.cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                ...product,
                quantity: 1
            });
        }
        
        this.saveCart();
        this.updateCartCounter();
        this.showNotification(`${product.name} added to cart!`, 'success');
        this.renderCart();
    }
    
    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== parseInt(productId));
        this.saveCart();
        this.updateCartCounter();
        this.renderCart();
        this.showNotification('Item removed from cart', 'info');
    }
    
    updateCartQuantity(productId, newQuantity) {
        const item = this.cart.find(item => item.id === parseInt(productId));
        if (item) {
            if (newQuantity <= 0) {
                this.removeFromCart(productId);
            } else {
                item.quantity = newQuantity;
                this.saveCart();
                this.renderCart();
            }
        }
    }
    
    renderCart() {
        const cartItems = document.getElementById('cartItems');
        const totalAmount = document.getElementById('totalAmount');
        
        if (!cartItems || !totalAmount) return;
        
        if (this.cart.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
                    <p>Your cart is empty</p>
                    <button class="btn btn-primary" onclick="app.closeModal('cartModal')">Continue Shopping</button>
                </div>
            `;
            totalAmount.textContent = '0.00';
            return;
        }
        
        cartItems.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <div class="cart-item-image">
                    <i class="fas fa-shoe-prints"></i>
                </div>
                <div class="cart-item-details">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-brand">${item.brand}</div>
                    <div class="cart-item-controls">
                        <button class="quantity-btn" onclick="app.updateCartQuantity(${item.id}, ${item.quantity - 1})">
                            <i class="fas fa-minus"></i>
                        </button>
                        <span class="quantity-display">${item.quantity}</span>
                        <button class="quantity-btn" onclick="app.updateCartQuantity(${item.id}, ${item.quantity + 1})">
                            <i class="fas fa-plus"></i>
                        </button>
                        <button class="remove-item" onclick="app.removeFromCart(${item.id})">
                            Remove
                        </button>
                    </div>
                </div>
                <div class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
            </div>
        `).join('');
        
        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        totalAmount.textContent = total.toFixed(2);
    }
    
    saveCart() {
        localStorage.setItem('footcap_cart', JSON.stringify(this.cart));
    }
    
    updateCartCounter() {
        const counter = document.getElementById('cartCounter');
        if (counter) {
            const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
            counter.textContent = totalItems;
            counter.style.display = totalItems > 0 ? 'flex' : 'none';
        }
    }
    
    // Wishlist Management
    toggleWishlist(productId) {
        const product = this.products.find(p => p.id === parseInt(productId));
        if (!product) return;
        
        const existingIndex = this.wishlist.findIndex(item => item.id === product.id);
        
        if (existingIndex > -1) {
            this.wishlist.splice(existingIndex, 1);
            this.showNotification(`${product.name} removed from wishlist`, 'info');
        } else {
            this.wishlist.push(product);
            this.showNotification(`${product.name} added to wishlist!`, 'success');
        }
        
        this.saveWishlist();
        this.updateWishlistCounter();
        this.updateWishlistButtons();
    }
    
    saveWishlist() {
        localStorage.setItem('footcap_wishlist', JSON.stringify(this.wishlist));
    }
    
    updateWishlistCounter() {
        const counter = document.getElementById('wishlistCounter');
        if (counter) {
            counter.textContent = this.wishlist.length;
            counter.style.display = this.wishlist.length > 0 ? 'flex' : 'none';
        }
    }
    
    updateWishlistButtons() {
        document.querySelectorAll('.wishlist-toggle').forEach(btn => {
            const productId = parseInt(btn.dataset.id);
            const isInWishlist = this.wishlist.some(item => item.id === productId);
            const icon = btn.querySelector('i');
            
            if (isInWishlist) {
                icon.className = 'fas fa-heart';
                btn.style.color = 'var(--primary-color)';
            } else {
                icon.className = 'far fa-heart';
                btn.style.color = '';
            }
        });
    }
    
    // Modal Management
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }
    
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }
    
    openQuickView(productId) {
        const product = this.products.find(p => p.id === parseInt(productId));
        if (!product) return;
        
        const quickViewContent = document.getElementById('quickViewContent');
        if (!quickViewContent) return;
        
        const isInWishlist = this.wishlist.some(item => item.id === product.id);
        const heartClass = isInWishlist ? 'fas fa-heart' : 'far fa-heart';
        
        quickViewContent.innerHTML = `
            <div class="quick-view-content">
                <div class="quick-view-image">
                    <i class="fas fa-shoe-prints" style="font-size: 6rem; color: var(--primary-color);"></i>
                </div>
                <div class="quick-view-details">
                    <div class="product-brand">${product.brand}</div>
                    <h3>${product.name}</h3>
                    <div class="product-price" style="font-size: 2rem; margin: 1rem 0;">$${product.price.toFixed(2)}</div>
                    <p class="product-description">${product.description}</p>
                    <div class="product-category">
                        <strong>Category:</strong> ${product.category}
                    </div>
                    <div class="quick-view-actions" style="margin-top: 2rem; display: flex; gap: 1rem;">
                        <button class="btn btn-primary" onclick="app.addToCart(${product.id}); app.closeModal('quickViewModal');">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                        <button class="btn btn-secondary" onclick="app.toggleWishlist(${product.id})">
                            <i class="${heartClass}"></i> ${isInWishlist ? 'Remove from' : 'Add to'} Wishlist
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        this.openModal('quickViewModal');
    }
    
    // Navigation
    setupNavigation() {
        // Hamburger menu
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('nav-menu');
        
        if (hamburger && navMenu) {
            hamburger.addEventListener('click', () => {
                hamburger.classList.toggle('active');
                navMenu.classList.toggle('active');
            });
        }
        
        // Navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href');
                this.scrollToSection(targetId);
                
                // Close mobile menu
                if (hamburger && navMenu) {
                    hamburger.classList.remove('active');
                    navMenu.classList.remove('active');
                }
                
                // Update active link
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            });
        });
        
        // Header scroll effect
        window.addEventListener('scroll', () => {
            const header = document.getElementById('header');
            if (header) {
                if (window.scrollY > 100) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            }
        });
    }
    
    scrollToSection(targetId) {
        const target = document.querySelector(targetId);
        if (target) {
            const headerHeight = document.getElementById('header')?.offsetHeight || 70;
            const targetPosition = target.offsetTop - headerHeight - 20;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }
    
    // Event Listeners
    setupEventListeners() {
        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.filterProducts(btn.dataset.filter);
            });
        });
        
        // Collection buttons
        document.querySelectorAll('.collection-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.filterProductsByCategory(btn.dataset.filter);
            });
        });
        
        // Search functionality
        const searchBtn = document.getElementById('searchBtn');
        const searchModal = document.getElementById('searchModal');
        const searchInput = document.getElementById('searchInput');
        
        if (searchBtn && searchModal) {
            searchBtn.addEventListener('click', () => {
                this.openModal('searchModal');
                setTimeout(() => {
                    if (searchInput) searchInput.focus();
                }, 300);
            });
        }
        
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    const query = e.target.value;
                    this.searchProducts(query);
                    
                    const suggestions = this.getSearchSuggestions(query);
                    this.renderSearchSuggestions(suggestions);
                }, 300);
            });
        }
        
        // Cart button
        const cartBtn = document.getElementById('cartBtn');
        if (cartBtn) {
            cartBtn.addEventListener('click', () => {
                this.renderCart();
                this.openModal('cartModal');
            });
        }
        
        // Newsletter form
        const newsletterForm = document.getElementById('newsletterForm');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleNewsletterSubmission();
            });
        }
        
        // Checkout button
        document.addEventListener('click', (e) => {
            if (e.target.id === 'checkoutBtn') {
                this.handleCheckout();
            }
        });
        
        // Dynamic event delegation for products
        document.addEventListener('click', (e) => {
            if (e.target.closest('.add-to-cart')) {
                const productId = e.target.closest('.add-to-cart').dataset.id;
                this.addToCart(productId);
            }
            
            if (e.target.closest('.wishlist-toggle')) {
                const productId = e.target.closest('.wishlist-toggle').dataset.id;
                this.toggleWishlist(productId);
            }
            
            if (e.target.closest('.quick-view')) {
                const productId = e.target.closest('.quick-view').dataset.id;
                this.openQuickView(productId);
            }
        });
    }
    
    // Modal Setup
    setupModals() {
        // Close modal buttons
        document.querySelectorAll('.modal-close').forEach(closeBtn => {
            closeBtn.addEventListener('click', () => {
                const modal = closeBtn.closest('.modal');
                if (modal) {
                    this.closeModal(modal.id);
                }
            });
        });
        
        // Close modal on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
        
        // Close modal on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal.show').forEach(modal => {
                    this.closeModal(modal.id);
                });
            }
        });
    }
    
    // Scroll Effects
    setupScrollEffects() {
        // Go to top button
        const goToTopBtn = document.getElementById('goToTop');
        if (goToTopBtn) {
            window.addEventListener('scroll', () => {
                if (window.scrollY > 500) {
                    goToTopBtn.classList.add('show');
                } else {
                    goToTopBtn.classList.remove('show');
                }
            });
            
            goToTopBtn.addEventListener('click', () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }
        
        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        document.querySelectorAll('.collection-card, .feature-card').forEach(el => {
            observer.observe(el);
        });
    }
    
    // Notifications
    showNotification(message, type = 'success') {
        const notifications = document.getElementById('notifications');
        if (!notifications) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        notifications.appendChild(notification);
        
        // Auto remove notification
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => {
                notifications.removeChild(notification);
            }, 300);
        }, 3000);
        
        // Click to close
        notification.addEventListener('click', () => {
            notification.classList.add('fade-out');
            setTimeout(() => {
                if (notifications.contains(notification)) {
                    notifications.removeChild(notification);
                }
            }, 300);
        });
    }
    
    // Newsletter Submission
    handleNewsletterSubmission() {
        const emailInput = document.getElementById('newsletterEmail');
        if (!emailInput) return;
        
        const email = emailInput.value.trim();
        if (!email) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }
        
        // Simulate newsletter subscription
        this.showNotification('Thank you for subscribing to our newsletter!', 'success');
        emailInput.value = '';
    }
    
    // Checkout
    handleCheckout() {
        if (this.cart.length === 0) {
            this.showNotification('Your cart is empty', 'error');
            return;
        }
        
        // Simulate checkout process
        this.showNotification('Redirecting to checkout...', 'info');
        setTimeout(() => {
            this.showNotification('Checkout functionality will be implemented soon!', 'info');
        }, 1500);
    }
    
    // Loading Screen
    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }, 1000);
        }
    }
}

// Utility Functions
function scrollToSection(targetId) {
    if (window.app) {
        window.app.scrollToSection(targetId);
    }
}

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FootcapApp();
});

// Service Worker Registration (for future PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/static/sw.js')
            .then(() => console.log('Service Worker registered'))
            .catch(() => console.log('Service Worker registration failed'));
    });
}