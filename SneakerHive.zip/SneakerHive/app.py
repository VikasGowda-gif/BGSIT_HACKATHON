from flask import Flask, render_template, jsonify, make_response
import os

app = Flask(__name__)

# Security: Disable debug mode in production
DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'

@app.route('/')
def home():
    """Main homepage route"""
    try:
        response = make_response(render_template('index.html'))
        # Add cache control headers for better performance
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
    except Exception as e:
        if DEBUG:
            raise e
        return make_response(jsonify({'error': 'Internal server error'}), 500)

@app.route('/api/products')
def get_products():
    """API endpoint to get product data"""
    try:
        products = [
            {
                "id": 1,
                "name": "Air Max 90",
                "brand": "Nike",
                "price": 120,
                "category": "running",
                "image": "nike-air-max-90.jpg",
                "description": "Comfortable running shoes with excellent cushioning"
            },
            {
                "id": 2,
                "name": "UltraBoost 22",
                "brand": "Adidas",
                "price": 180,
                "category": "running",
                "image": "adidas-ultraboost.jpg",
                "description": "Premium running shoes with boost technology"
            },
            {
                "id": 3,
                "name": "Suede Classic",
                "brand": "Puma",
                "price": 75,
                "category": "casual",
                "image": "puma-suede.jpg",
                "description": "Classic casual sneakers with timeless style"
            },
            {
                "id": 4,
                "name": "Formal Oxford",
                "brand": "Bata",
                "price": 95,
                "category": "formal",
                "image": "bata-oxford.jpg",
                "description": "Professional oxford shoes for business occasions"
            },
            {
                "id": 5,
                "name": "Performance Runner",
                "brand": "Apex",
                "price": 110,
                "category": "running",
                "image": "apex-runner.jpg",
                "description": "High-performance running shoes for athletes"
            },
            {
                "id": 6,
                "name": "Jordan 1 Retro",
                "brand": "Nike",
                "price": 170,
                "category": "basketball",
                "image": "nike-jordan-1.jpg",
                "description": "Iconic basketball shoes with premium leather"
            },
            {
                "id": 7,
                "name": "Stan Smith",
                "brand": "Adidas",
                "price": 85,
                "category": "casual",
                "image": "adidas-stan-smith.jpg",
                "description": "Timeless white leather tennis shoes"
            },
            {
                "id": 8,
                "name": "RS-X",
                "brand": "Puma",
                "price": 100,
                "category": "sports",
                "image": "puma-rsx.jpg",
                "description": "Retro-futuristic running shoes with bold design"
            }
        ]
        
        response = make_response(jsonify(products))
        response.headers['Content-Type'] = 'application/json'
        return response
        
    except Exception as e:
        if DEBUG:
            raise e
        return make_response(jsonify({'error': 'Unable to load products'}), 500)

@app.errorhandler(404)
def page_not_found(error):
    """Handle 404 errors"""
    return make_response(jsonify({'error': 'Page not found'}), 404)

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return make_response(jsonify({'error': 'Internal server error'}), 500)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=DEBUG)